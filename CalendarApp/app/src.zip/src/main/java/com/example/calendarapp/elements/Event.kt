package com.example.calendarapp.elements

import java.time.LocalDate
import java.time.LocalTime

class Event(
    val name: String,
    val date: LocalDate,
    val time: LocalTime
) {
    companion object {
        var eventsList = ArrayList<Event>()

        fun eventsForDate(date: LocalDate): ArrayList<Event> {
            val events = ArrayList<Event>()

            for (event in eventsList) {
                if (event.date == date)
                    events.add(event)
            }

            return events
        }

        fun eventsForDateAndTime(date: LocalDate, time: LocalTime): ArrayList<Event> {
            val events = ArrayList<Event>()

            for (event in eventsList) {
                if (event.date == date && event.time.hour == time.hour)
                    events.add(event)
            }

            return events
        }
    }
}
