package com.example.calendarapp.elements

import java.time.LocalTime

class HourEvent(
    var time: LocalTime,
    var events: ArrayList<Event>
)
